//
//  ViewController.swift
//  Delegates
//
//  Created by iOSLab on 30/09/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputName: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        DetailViewController.delegate = self
    }
}

extension ViewController: DetailViewControllerDelegate {
    func getName() -> String? {
        inputName.text
    }
}
