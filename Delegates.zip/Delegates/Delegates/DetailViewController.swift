//
//  DetailViewController.swift
//  Delegates
//
//  Created by iOSLab on 30/09/24.
//

import UIKit

protocol DetailViewControllerDelegate {
    func getName() -> String?
}

class DetailViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    static var delegate: DetailViewControllerDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = DetailViewController.delegate?.getName()
    }
}
